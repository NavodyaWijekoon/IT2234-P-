
let students=[
    {regno:'2021ICT62',name:'Navodya',gender:'female',age:22,course:'IT'},
    {regno:'2021ICT08',name:'James',gender:'male',age:23,course:'IT'},
    {regno:'2021ICT07',name:'Lison',gender:'male',age:21,course:'Bio'},
    {regno:'2021ICT06',name:'Rose',gender:'female',age:22,course:'Maths'},
    {regno:'2021ICT05',name:'John',gender:'male',age:21,course:'IT'}
    ];

module.exports=students;